import json

# Class for creating an account
class CreateAccount:
    def __init__(self):
        # Initialize account details
        self.name = ""
        self.password = ""
        self.mobileNumber = ""

    # Method to create an account
    def create(self):
        print("------Create Account------")
        # Gather account details from user input
        self.name = input("Enter your name: ")
        self.password = input("Enter your password: ")
        # Check if password is at least 8 characters long
        if len(self.password) < 8:
            print("Password should be at least 8 characters long.")
            # Recursively call create method until a valid password is provided
            self.create()
        
        # Validate mobile number format
        while True:
            self.mobileNumber = input("Enter your mobile number: ")
            if len(self.mobileNumber) != 10 or not self.mobileNumber.isdigit():
                print("Enter valid mobile number")
                continue
            break
        print("Account created successfully")
        # After account creation, show menu
        self.menu()

    # Method to modify account details
    def modify(self):
        print("Choose action to modify: ")
        print("1) Change Password")
        print("2) Change Mobile number")
        print("3) Change Name")
        print("4) Exit")
        modification = input("Enter your action number: ")
        if modification == "1":
            previous_pass = input("Enter current password: ")
            if self.password == previous_pass:
                self.password = input("Enter New Password: ")
                if len(self.password) < 6:
                    print("Enter at least 6 character password")
                print("Password Changed successfully")
            else:
                print("Previous Password is incorrect")
                self.modify()
        elif modification == "2":
            while True:
                self.mobileNumber = input("Enter New Mobile Number: ")
                if len(self.mobileNumber) != 10 or not self.mobileNumber.isdigit():
                    print("Enter valid mobile number")
                    continue
                break
        elif modification == "3":
            previous_name = input("Enter Previous Name: ")
            if self.name == previous_name:
                new_name = input("Enter New Name: ")
                self.name = new_name
                print("Name changed Successfully")
            else:
                print("Incorrect Name Entered")
                self.modify()
        elif modification == "4":
            print("Exiting the modification process")
        else:
            print("Invalid action ! try again!!!")
            self.modify()
        print()
        # After modification, show menu
        self.menu()

    # Method to display account details
    def display(self):
        print("------Details------")
        print(f"Name: {self.name}")
        print(f"Mobile number: {self.mobileNumber}")
        print()
        self.menu()

    # Method to display menu options
    def menu(self):
        print("""1) To create Account
2) To modify Account
3) To Display Account Information
4) Exit/Guest Login""")
        choice = input("Enter Choice: ")
        if choice == '1':
            self.create()
        elif choice == '2':
            self.modify()
        elif choice == '3':
            self.display()
        elif choice == '4':
            exit
        else:
            print("Invalid Choice!! Try Again")
            self.menu()

# Class for shopping functionality
class Shopping:
    def __init__(self):
        self.cart = []

    # Method to display categories and get user choice
    def menu(self):
        print("-----Categories-----")
        print("1) Mobiles, computers")
        print("2) TV, appliances, and Electronic")
        print("3) Men's Fashion")
        print("4) Women's Fashion")
        print("5) Home, Kitchen Appliances")
        print("6) Books")
        print("7) Toys")
        print("8) Sports product")
        print("9) Exit -> View Cart")
        choice = input("Please enter your category code: ")
        # Depending on choice, display items
        if choice == '1':
            self.display_items("C:/Users/ravir/Desktop/Python_individual/Python_individual/mobile.json")
        elif choice == '2':
            self.display_items("C:/Users/ravir/Desktop/Python_individual/Python_individual/otherElectricItems.json")
        elif choice == '3':
            self.display_items("C:/Users/ravir/Desktop/Python_individual/Python_individual/mensFashion.json")
        elif choice == '4':
            self.display_items("C:/Users/ravir/Desktop/Python_individual/Python_individual/womensFashion.json")
        elif choice == '5':
            self.display_items("C:/Users/ravir/Desktop/Python_individual/Python_individual/homeProducts.json")
        elif choice == '6':
            self.display_items("C:/Users/ravir/Desktop/Python_individual/Python_individual/books.json")
        elif choice == '7':
            self.display_items("C:/Users/ravir/Desktop/Python_individual/Python_individual/toys.json")
        elif choice == '8':
            self.display_items("C:/Users/ravir/Desktop/Python_individual/Python_individual/sportsProduct.json")
        elif choice == '9':
            self.view_cart()
        else:
            print("Invalid Choice! Try Again.")

    # Method to display items in a chosen category
    def display_items(self, file_path):
        with open(file_path) as file:
            data = json.load(file)
        for i, item in enumerate(data):
            print(f"{i+1}) {item['product_name']} - Price: {item['price']} INR")
            print()
        # After displaying items, ask user to add to cart
        self.add_to_cart(data)

    # Method to add items to the cart
    def add_to_cart(self, items):
        choice = input("Enter the item number to add to cart or 'q' to quit: ")
        if choice.lower() == 'q':
            self.view_cart()
        else:
            try:
                item_index = int(choice) - 1
                self.cart.append(items[item_index])
                print(f"Added {items[item_index]['product_name']} to cart.")
                self.menu()
            except (IndexError, ValueError):
                print("Invalid item number. Try Again.")
                self.add_to_cart(items)

    # Method to view items in the cart
    def view_cart(self):
        print("\nYour Cart:")
        for item in self.cart:
            print(f"{item['product_name']} - Price: {item['price']} INR")
        self.make_bill()

    # Method to calculate and display total price
    def make_bill(self):
        total_price = sum(item['price'] for item in self.cart)
        print(f"\nTotal Price: {total_price} INR")
        choice = input("Do you want to make a purchase? (y/n): ")
        if choice.lower() == 'y':
            print("Thank you for shopping with us!")
        else:
            print("Exiting the shopping cart.")

    # Method to save cart details to a file
    def save_cart_to_file(self, customer_name, customer_mobile_number, total_price):
        with open("Bill.txt", "w") as file:
            file.write("---------------------Customer Details------------------------\n")
            file.write(f"Customer Name: {customer_name}\n")
            file.write(f"Customer Mobile Number: {customer_mobile_number}\n")
            file.write("---------------------------------------------\n")
            file.write("Items in Cart:\n\n")
            for item in self.cart:
                file.write(f"{item['product_name']} - Price: {item['price']} INR\n")
            file.write("---------------------------------------------\n")
            file.write(f"Total Price: {total_price} INR\n")

# Main program starts here
# Create account instance
login = CreateAccount()
login.menu()
# Get account details
customer_name = login.name
customer_mobile_number = login.mobileNumber
print('\nLogged In Successfully!\n')
# Start shopping
shop = Shopping()
shop.menu()
# Calculate total price
total_price = sum(item['price'] for item in shop.cart)
# Save cart details to file
shop.save_cart_to_file(customer_name, customer_mobile_number, total_price)
